package model;

public class Cavalier extends AbstractPiece {

	public Cavalier(Couleur couleur, Coord coord) {
		super(couleur, coord);
	}

	@Override
	//Retourne true si déplacement légal en fonction des algo de déplacement spécifique de chaque pièce
	// le cavalier se deplace en L ( 2 puis 1)
	public boolean isMoveOk(int xFinal, int yFinal) {
		int dx = xFinal-this.getX();
		//deplacement en y
		int dy = yFinal-this.getY();
		// si X-1<=xFinal<=X+1 et si Y-1<=yFinal<=Y+1 il faut que le deplacement ne soit pas superieur à 1
		return -1<= dx && 1>= dx && -1<= dy && 1>= dy ;
	}

}
