package model;

import java.util.LinkedList;
import java.util.List;

import tools.ChessPiecesFactory;

public class Jeu {
	private Couleur couleur;
	private List <Pieces> pieces; 
	
	public Jeu(Couleur couleur){
		this.couleur=couleur;
		this.pieces=ChessPiecesFactory.newPieces(this.couleur);//on recup la liste de pieces
	}
	
	public Couleur getCouleur(){
		return this.couleur;
	}
	
	//Recupère les coord(x,y) d'une pièce sur les coord
	private Pieces findPiece(int x, int y){
		 for (int i=0; i<pieces.size(); i++){
			 if(x==this.pieces.get(i).getX() && y==this.pieces.get(i).getY()){	//On récup les coord(x,y) dans la liste pieces
				 return pieces.get(i);
			 }
		 }
		return null;
	}
	
	//true si une pièce se trouve aux coordonnées indiquées
		public boolean isPieceHere(int x,int y){
			boolean ret =false; 
		    if(findPiece(x,y)!=null){
		    		ret = true;
		    }
		    return ret;
		}
	
/*	public java.lang.String toString(){
		//TODO
		return "salut";
	}*/
	
	//true si piece du jeu peut être déplacée aux coordonnées finales, false sinon
	public boolean isMoveOk(int xInit, int yInit, int xFinal, int yFinal){
		boolean ret = false;
		Pieces piecesinitiales= findPiece(xInit,yInit);
		Pieces piecesfinales= findPiece(xFinal,yFinal);
		
		//Si il y a déjà une pièce sur les coord finales on regarde la couleur de la pièce
		if (isPieceHere(xFinal,yFinal)){
				if (piecesfinales.getCouleur()!=this.getCouleur()){
					return ret;
				}
		}
		//on vérie si le déplacement est autorisé
		return(piecesinitiales.isMoveOk(xFinal, yFinal));
		
	}
	
	//true si déplacement pièce effectué
	public boolean move(int xInit, int yInit, int xFinal, int yFinal){
		return(xInit==xFinal && yInit==yFinal);
	}
	
	//couleur de la pièce aux coordonnées x, y
	public Couleur getPieceColor(int x,int y){
		Pieces pieces = findPiece(x,y);
		return(pieces.getCouleur());
	}
	
	//type de la pièce aux coordonnées x,y c'est à dire le nom de la classe : maPiece.getClass().getSimpleName();
	public java.lang.String getPieceType(int x,int y){
		Pieces MaPiece = findPiece(x,y);
		return(MaPiece.getClass().getSimpleName());
	}
	/**
	* @return une vue de la liste des pièces en cours
	* ne donnant que des accès en lecture sur des PieceIHM
	* (type piece + couleur + liste de coordonnées)
	*/
	public List<PieceIHM> getPiecesIHM(){
		PieceIHM newPieceIHM = null;
		List<PieceIHM> list = new LinkedList<PieceIHM>();
		for (Pieces piece : pieces){
//			boolean existe = false;
			// si le type de piece existe déjà dans la liste de PieceIHM
			// ajout des coordonnées de la pièce dans la liste de Coord de ce type
			// si elle est toujours en jeu (x et y != -1)
//				for ( PieceIHM pieceIHM : list){
////					if ((pieceIHM.getTypePiece()).equals(piece.getClass().getSimpleName())){
////						existe = true;
////							if (piece.getX() != -1){
////								pieceIHM.add(new Coord(piece.getX(), piece.getY()));
////							}
////						}
////					}
//				
//	// sinon, création d'une nouvelle PieceIHM si la pièce est toujours en jeu
//					if (! existe) {
//						if (piece.getX() != -1){
//	//						newPieceIHM = new PieceIHM(piece.getClass().getSimpleName(),
//	//						piece.getCouleur());
//	//						newPieceIHM.add(new Coord(piece.getX(), piece.getY()));
//	//						list.add(newPieceIHM);
//							newPieceIHM = new PieceIHM(piece.getClass().getSimpleName(),
//												piece.getCouleur(), 
//												new Coord(piece.getX(), piece.getY()));
//							list.add(newPieceIHM);
//						}
//					}
					
					
					if (piece.getX() != -1){
						newPieceIHM = new PieceIHM(piece.getClass().getSimpleName(),
											piece.getCouleur(), 
											new Coord(piece.getX(), piece.getY()));
						list.add(newPieceIHM);
					}
					
//				}
				
		}
		return list;
	}
		
	public String toString(){
	String ret="";
	for(int i=0;i<= pieces.size()-1;i++){
		ret= ret + "\n" +pieces.get(i).toString();
	}
	return ret;
	}
	
	public boolean capture(int xCatch, int yCatch){
		//TODO
		return false;
	}
	
}
