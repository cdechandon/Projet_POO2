package model;

public class Tour extends AbstractPiece{

	public Tour(Couleur couleur_de_piece, Coord coord){
		super(couleur_de_piece, coord);
	}


	@Override
	//Retourne true si déplacement légal en fonction des algo de déplacement spécifique de chaque pièce
	//La tour se déplace selon une ligne ou une colonne
	public boolean isMoveOk(int xFinal, int yFinal) {
		return (getX()==xFinal || getY()==yFinal);
	}



}