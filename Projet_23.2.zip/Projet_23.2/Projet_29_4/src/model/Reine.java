package model;

public class Reine extends AbstractPiece{
	
	public Reine (Couleur couleur, Coord coord) {
		super(couleur, coord);
	}

	Pieces maTour =  new Tour(Couleur.NOIR, new Coord(this.getX(),this.getY()));
	Pieces monFou =  new Fou(Couleur.NOIR, new Coord(this.getX(),this.getY()));
	

	@Override
	//Retourne true si déplacement légal en fonction des algo de déplacement spécifique de chaque pièce
	//La reine peut avoir le déplacement d'un fou ou d'une tour
	public boolean isMoveOk(int xFinal, int yFinal) {
		return (maTour.isMoveOk(xFinal, yFinal) || monFou.isMoveOk(xFinal, yFinal));//
	}
	
	
}
