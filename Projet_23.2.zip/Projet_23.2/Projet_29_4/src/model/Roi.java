package model;

public class Roi extends AbstractPiece{

	public Roi(Couleur couleur, Coord coord) {
		super(couleur, coord);
	}

	@Override
	//Retourne true si déplacement légal en fonction des algo de déplacement spécifique de chaque pièce
	// Le roi peut se deplacer d'une case dans toutes les directions
	public boolean isMoveOk(int xFinal, int yFinal) {
		return (((Math.abs(xFinal-this.getX()))<=1) && ((Math.abs(yFinal-this.getY()))<=1));
	}
	

}
