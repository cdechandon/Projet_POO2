package model;

public abstract class AbstractPiece implements Pieces{
	private String name;
	private Couleur couleur;
	private Coord coord;
	
	
	public AbstractPiece(Couleur couleur,Coord coord){
		super();
		this.couleur=couleur;
		this.coord=coord;
		this.name=getClass().getSimpleName();
	}

	@Override
	//Retoune l'indice de la colonne où est positionnée la pièce
	public int getX() {
		return coord.x;
	}


	@Override
	//Retoune l'indice de la ligne où est positionnée la pièce
	public int getY() {
		return coord.y;
	}


	@Override
	//Retoune la couleur de la pièce 
	public Couleur getCouleur() {
		return couleur;
	}


	@Override
	//retourne true si déplacement effectué
	//effectue le déplacement
	//Vérifie que (x,y) sont dans les limites du damier
	public boolean move(int xFinal, int yFinal) {
		if(coord.x <=7 && coord.x>=0){
			coord.x = xFinal;
			}
		if(coord.y <=7 && coord.y>=0){
			coord.y = yFinal;
		}
		return true;
	}



	@Override
	//retoune true si pièce effectivement capturée et positionne x et y à -1
	public boolean capture() {
		coord.x=-1;
		coord.y=-1;
		return true;
	}
	
	@Override
	//On redéfinit la méthode toString héritée d'Obj pour toutes les pièces
	//Renvoie nom pièce + Coord(x,y)
	public String toString() {
		return "\n"+"La pièce "+ name + " est placée en x= " + getX() + " et en y=" + getY() ;
	}

	
	public abstract  boolean isMoveOk(int xFinal, int yFinal) ;
	
	
	public static void main(String[] args){
		Pieces monRoi =  new Roi(Couleur.NOIR, new Coord(0,0));
		System.out.println(monRoi.isMoveOk(0,1));
		
	}

}
