package vue;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.ImageObserver;
import java.awt.MenuContainer;
import java.io.Serializable;
import java.util.EventListener;
import java.util.Observer;
import javax.accessibility.Accessible;
import javax.swing.RootPaneContainer;
import javax.swing.WindowConstants;

/*public class ChessGameGUI extends javax.swing.JFrame implements java.awt.event.MouseListener, java.awt.event.MouseMotionListener, java.util.Observer{
	
	public ChessGameGUI (java.lang.String name,ChessGameControlers chessGameControler,java.awt.Dimension boardSize){
		
	}
}*/