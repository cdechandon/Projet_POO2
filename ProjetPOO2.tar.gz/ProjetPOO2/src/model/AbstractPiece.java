package model;

public abstract class AbstractPiece implements Pieces{
	private String name;
	private Couleur couleur;
	private Coord coord;
	
	
	public AbstractPiece(Couleur couleur,Coord coord){
		super();
		this.couleur=couleur;
		this.coord=coord;
		this.name=getClass().getSimpleName();
	}

	@Override
	//Retoune l'indice de la colonne où est positionnée la pièce
	public int getX() {
		return coord.x;
	}


	@Override
	//Retoune l'indice de la ligne où est positionnée la pièce
	public int getY() {
		return coord.y;
	}


	@Override
	//Retoune la couleur de la pièce 
	public Couleur getCouleur() {
		return couleur;
	}


	@Override
	//retourne true si déplacement effectué
	public boolean move(int xFinal, int yFinal) {
		return (this.getX()==xFinal && this.getY()==yFinal);
	}



	@Override
	//retoune true si pièce effectivement capturée et positionne x et y à -1
	public boolean capture() {
		coord.x=-1;
		coord.y=-1;
		return true;
	}
	
	@Override
	//On redéfinit la méthode toString héritée d'Obj pour toutes les pièces
	//Renvoie nom pièce + Coord(x,y)
	public String toString() {
		return "\n"+"La pièce "+ name + " est placée en x= " + getX() + " et en y=" + getY() ;
	}

	public static void main(String[] args){
		Pieces monRoi =  new Roi(Couleur.NOIR, new Coord(0,0));
		System.out.println(monRoi.isMoveOk(0,1));
		
	}

}
